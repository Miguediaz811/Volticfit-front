import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { RegexPatterns } from '../../shared/validators/regex.constanst';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  form!: FormGroup;
  isLoading    = false;
  errorMessage = '';
  showPassword = false;

  constructor(
    private fb:     FormBuilder,
    private auth:   AuthService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    if (this.auth.isAuthenticated()) {
      this.redirect();
      return;
    }
    this.form = this.fb.group({
      correo:    ['', [Validators.required, Validators.pattern(RegexPatterns.email)]],
      contrasena: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  get correo()    { return this.form.get('correo')!; }
  get contrasena() { return this.form.get('contrasena')!; }

  togglePassword(): void { this.showPassword = !this.showPassword; }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }

    this.isLoading    = true;
    this.errorMessage = '';

    this.auth.login(this.form.value).subscribe({
      next:  () => { this.isLoading = false; this.redirect(); },
      error: (err) => {
        this.isLoading    = false;
        this.errorMessage = err.error?.error ?? 'Credenciales incorrectas. Intenta de nuevo.';
      },
    });
  }

  private redirect(): void {
    const rutas: Record<string, string> = {
      admin:      '/admin/dashboard',
      instructor: '/instructor/dashboard',
      aprendiz:   '/aprendiz/dashboard',
    };
    this.router.navigate([rutas[this.auth.getRol() ?? ''] ?? '/aprendiz/dashboard']);
  }
}